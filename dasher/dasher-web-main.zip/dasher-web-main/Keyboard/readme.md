# Keyboard Proof of Concept
This directory was for custom keyboard proofs of concept. That code has been
moved to another repository. See:  
[https://github.com/dasher-project/dasher-captivewebview/tree/main/Keyboard](https://github.com/dasher-project/dasher-captivewebview/tree/main/Keyboard)
