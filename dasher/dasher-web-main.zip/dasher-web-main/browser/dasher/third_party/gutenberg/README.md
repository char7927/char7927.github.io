## Project Gutenberg Data

The files in this directory contain full books from [Project
Gutenberg](https://www.gutenberg.org/) encoded as JavaScript strings:

1.  [alice.js](alice.js): EBook #11: [Alice's Adventures in Wonderland by Lewis Carroll](https://www.gutenberg.org/ebooks/11).
2.  [sherlock.js](sherlock.js): EBook #48320: [Adventures of Sherlock Holmes](https://www.gutenberg.org/ebooks/48320)

Please see the [LICENSE](LICENSE) file in this directory which
contains the link to Project Gutenberg terms and conditions.
