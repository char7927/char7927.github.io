# Third-party components

## jslm

A copy of a small
[library](https://github.com/google-research/google-research/tree/master/jslm)
of dynamic language models in JavaScript by Google.  The copy contains a subset
of the classes required to implement the Prediction by Partial Matching (PPM)
language model.
